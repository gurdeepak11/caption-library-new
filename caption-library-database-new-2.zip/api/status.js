const { neon } = require("@neondatabase/serverless");

module.exports = async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  if (req.method !== "GET") return res.status(405).json({ error: "Method not allowed" });
  if (!process.env.DATABASE_URL) return res.status(500).json({ error: "DATABASE_NOT_CONFIGURED" });

  const userId = String(req.headers["x-user-id"] || "").trim();
  if (!userId) return res.status(400).json({ error: "USER_ID_REQUIRED" });

  const sql = neon(process.env.DATABASE_URL);
  await sql`INSERT INTO users (id) VALUES (${userId}) ON CONFLICT (id) DO NOTHING`;
  const rows = await sql`
    SELECT free_uses, subscription_status FROM users WHERE id = ${userId} LIMIT 1
  `;
  const u = rows[0];

  res.status(200).json({
    freeUses: Number(u.free_uses),
    remainingFreeUses: u.subscription_status === "active" ? null : Math.max(0, 3 - Number(u.free_uses)),
    subscribed: u.subscription_status === "active"
  });
};
