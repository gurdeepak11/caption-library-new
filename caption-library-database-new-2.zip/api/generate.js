const { neon } = require("@neondatabase/serverless");

module.exports = async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, X-User-ID");

  if (req.method === "OPTIONS") return res.status(204).end();
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  if (!process.env.DATABASE_URL) {
    return res.status(500).json({
      error: "DATABASE_NOT_CONFIGURED",
      message: "DATABASE_URL is not configured on the server."
    });
  }

  const sql = neon(process.env.DATABASE_URL);
  const userId = String(req.headers["x-user-id"] || "").trim();
  const body = req.body || {};
  const category = String(body.category || "General").trim();
  const country = String(body.country || "").trim();
  const sport = String(body.sport || "").trim();
  const input = String(body.input || "").trim();

  if (!userId) return res.status(400).json({ error: "USER_ID_REQUIRED" });
  if (!input) return res.status(400).json({ error: "INPUT_REQUIRED" });

  await sql`
    INSERT INTO users (id) VALUES (${userId})
    ON CONFLICT (id) DO NOTHING
  `;

  const users = await sql`
    SELECT free_uses, subscription_status
    FROM users WHERE id = ${userId}
    LIMIT 1
  `;
  const user = users[0];

  if (user.subscription_status !== "active" && user.free_uses >= 3) {
    return res.status(402).json({
      error: "SUBSCRIPTION_REQUIRED",
      message: "Your 3 free uses are finished. Please subscribe to continue."
    });
  }

  const rows = await sql`
    SELECT title_template, caption_template, hashtags
    FROM captions
    WHERE category = ${category}
      AND (${country} = '' OR country = ${country})
      AND (${sport} = '' OR sport = ${sport})
    ORDER BY RANDOM()
    LIMIT 1
  `;

  if (!rows.length) {
    return res.status(404).json({
      error: "NO_DATABASE_TEMPLATE",
      message: "No matching caption template exists in the database yet."
    });
  }

  const row = rows[0];
  const replace = (text) => text.replaceAll("{{input}}", input)
    .replaceAll("{{country}}", country)
    .replaceAll("{{sport}}", sport);

  const title = replace(row.title_template);
  const caption = replace(row.caption_template);
  const hashtags = replace(row.hashtags);

  if (user.subscription_status !== "active") {
    await sql`
      UPDATE users SET free_uses = free_uses + 1 WHERE id = ${userId}
    `;
  }

  return res.status(200).json({
    ok: true,
    title,
    caption,
    hashtags,
    sameTitleForAllSocialMedia: true,
    remainingFreeUses: user.subscription_status === "active"
      ? null
      : Math.max(0, 2 - Number(user.free_uses))
  });
};
