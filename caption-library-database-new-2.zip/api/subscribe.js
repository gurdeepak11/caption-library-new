const { neon } = require("@neondatabase/serverless");

module.exports = async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });
  if (!process.env.DATABASE_URL) return res.status(500).json({ error: "DATABASE_NOT_CONFIGURED" });

  const userId = String(req.headers["x-user-id"] || "").trim();
  if (!userId) return res.status(400).json({ error: "USER_ID_REQUIRED" });

  // Payment provider integration goes here.
  // Do NOT mark a user active merely because this endpoint was called.
  res.status(501).json({
    error: "PAYMENT_NOT_CONNECTED",
    message: "Choose a payment provider first; payment verification must happen server-side."
  });
};
